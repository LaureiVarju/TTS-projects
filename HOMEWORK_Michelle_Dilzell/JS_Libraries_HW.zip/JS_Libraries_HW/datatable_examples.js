console.log("top of JS");

var arr = [1, 4, 5, 12, 55, 24, 69, 13, 5, 8, 12];
var theObj = { id: 1, name: "Tom Henry", state: "KS" };
var arrObj = [
  { id: 6, name: "Will Turner", state: "KS" },
  { id: 7, name: "Dawn Williams", state: "NC" },
  { id: 8, name: "Sean Cunningham", state: "NC" },
  { id: 9, name: "Ted Hardy", state: "TX" },
  { id: 10, name: "Bruce Matthis", state: "FL" },
  { id: 11, name: "Billy Smith", state: "FL" },
  { id: 12, name: "Clara Jarvis", state: "TX" },
  { id: 13, name: "Cindy Fisher", state: "CO" },
  { id: 14, name: "Gino Donovan", state: "CO" },
  { id: 15, name: "Nancy Curtis", state: "NC" }
];

//More to come