Name: Michelle Dilzell
Github user id: LaureiVarju
Assignment Title: Vegas Dice Game
Assigned: 8/30/19 

Link to the ongoing assignment in github: 
https://github.com/LaureiVarju/TTS-projects/tree/master/HOMEWORK_Michelle_Dilzell/Java_Dice_Games

Status:
This Homework includes two packages, simulating the game of Craps.

The first package, DilzellDice, is a version of the game where the player interacts with the console with inputs.

The second package, DilzellDiceSimple is a fully automated version of the game that prints results out to the console. 
