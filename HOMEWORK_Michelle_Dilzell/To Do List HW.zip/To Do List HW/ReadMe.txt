Name: Michelle Dilzell
Github user id: LaureiVarju
Assignment Title: Angular Basics Homework
Assigned: 8/21/19 

Link to the ongoing assignment in github: 
https://github.com/LaureiVarju/TTS-projects/tree/master/HOMEWORK_Michelle_Dilzell/

Homework Status & Notes:
***Many elements of this assignment were created following W3schools.com tutorials, codepen resources, and youtube videos.***

Assignment parameters:
Show an unordered list of todo's

Show an input to enter a new todo

Show a button to add a todo. When the button is clicked:

The text from the input box is used to add a list item to the bottom of the list

The text from the input box is cleared out.

When the user clicks on a list item, it is removed