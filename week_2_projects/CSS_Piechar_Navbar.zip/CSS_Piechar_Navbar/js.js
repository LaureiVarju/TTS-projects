@media (min-width: 30rem) {
    nav {
      grid-template-columns: 1fr auto auto;
      justify-items: start;
    }
  }